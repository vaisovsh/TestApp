package com.example.exam.data.model

data class ContactData(
    val name:String,
    val phoneNumber: String,
    val image: Int
)
