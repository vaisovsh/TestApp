package com.example.exam.mvp.presenter

import android.util.Log
import com.example.exam.data.model.ContactData
import com.example.exam.mvp.contracts.MainContracts
import com.example.exam.mvp.model.MainModel

class MainPresenter (val view : MainContracts.View): MainContracts.Presenter{
    private var model: MainContracts.Model = MainModel()
    private val dataList: MutableList<ContactData> = ArrayList()


    override fun saveListData(data: ContactData) {
        dataList.add(data)

    }

    override fun clickedAddButton() {
        view.setClickAction()
    }




}