package com.example.exam.mvp.contracts

import com.example.exam.data.model.ContactData

interface MainContracts {
    interface Model{
        fun saveListData(list: ArrayList<ContactData>)
        fun getListData() : ArrayList<ContactData>
    }
    interface Presenter{
        fun saveListData(data: ContactData)
        fun clickedAddButton()

    }

    interface View{
        fun addButtonClicked()
        fun setClickAction()

    }

}