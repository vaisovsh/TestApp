package com.example.exam.mvp.view

import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import com.example.exam.App.App
import com.example.exam.R
import com.example.exam.data.model.ContactData
import com.example.exam.mvp.contracts.MainContracts
import com.example.exam.mvp.presenter.MainPresenter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import de.hdodenhof.circleimageview.CircleImageView

class MainActivity : AppCompatActivity(), MainContracts.View {
    private lateinit var addButton: FloatingActionButton
    private lateinit var presenter: MainContracts.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findView()
        presenter = MainPresenter(this)
        addButtonClicked()

    }

    private fun findView(){
        addButton = findViewById(R.id.addId)
    }

    override fun addButtonClicked() {
        addButton.setOnClickListener{
            presenter.clickedAddButton()
        }
    }



    override fun setClickAction() {
        var id: Int = -1
        var lastId: Int = -1
        val dialog: Dialog = Dialog(this)
        dialog.setContentView(R.layout.bg_dialog)
        dialog.setCancelable(false)
        dialog.show()

        val fullNameId = dialog.findViewById<EditText>(R.id.fullnameId)
        val phoneNumberId = dialog.findViewById<EditText>(R.id.phoneNumberId)
        val saveButtonID = dialog.findViewById<Button>(R.id.saveId)
        val containerImages = dialog.findViewById<LinearLayout>(R.id.containerImages)

        for(i in 0 until containerImages.childCount){
            val child = containerImages.getChildAt(i) as CircleImageView
            child.setOnClickListener {
                child.setBackgroundResource(R.drawable.bg_image)
                id = i
                if(lastId == -1){
                    lastId = id
                }else{
                    containerImages.getChildAt(lastId).setBackgroundResource(R.color.white)
                    lastId = i
                }
            }
        }


        fullNameId.showSoftInputOnFocus = false
        phoneNumberId.showSoftInputOnFocus = false


        saveButtonID.setOnClickListener{
            presenter.saveListData(ContactData(fullNameId.text as String, phoneNumberId.text as String, when(id){
                0 ->{
                    R.drawable.man
                }
                1 ->{
                    R.drawable.avatar
                }
                2 ->{
                    R.drawable.user
                }
                3 ->{
                    R.drawable.user__1_
                }
                4 ->{
                    R.drawable.woman
                }
                else ->{
                    R.drawable.man
                }
            }))
        }


    }


}